export const environment = {
     firebaseConfig : {
        apiKey: "AIzaSyATeapMAOWZjZ4sPe_b17i1xqPHkadSQbQ",
        authDomain: "shifts-2-28369.firebaseapp.com",
        projectId: "shifts-2-28369",
        storageBucket: "shifts-2-28369.appspot.com",
        messagingSenderId: "8812131012",
        appId: "1:8812131012:web:45d98841a4ff6869874f91",
        measurementId: "G-8EQZK02KLN"
      }
};
